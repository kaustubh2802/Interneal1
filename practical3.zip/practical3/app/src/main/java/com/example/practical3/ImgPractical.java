package com.example.practical3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ImageButton;
import android.widget.Toast;

public class ImgPractical extends AppCompatActivity {
    ImageButton Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_img_practical);


        // Initializing the variable for image button
        Button = (ImageButton) findViewById(R.id.imageButton);
// Below code is for setting a click listener on the image
        Button.setOnClickListener(view -> {
// Creating a toast to display the message
            Toast.makeText(ImgPractical.this,"Welcome to DMI",Toast.LENGTH_SHORT).show();
            //Toast.makeText(activity_img.this, "Welcome to Google", Toast.LENGTH_SHORT).show();
                    String url = "https://www.google.co.in/";
// Creating an explicit intent to open the
// link stored in variable url
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        });

    }
 }

 //hello world, addition of two numbrs, login activity, image,dialog,

//    create xml and java file for each:
//        main activity contains welcome msg and 1 button (after clicking on button set intent to next activity that is addition activity)
//        in the addition acitivity the design is 3 textview(2 for enter number, 1 for showing addition), 2 edit text(for input), 2 buttons(calculate & next) if i clicked on the calculte the 2 values get and do addition and show it to 3rd text view for showing addition
//        and if i clicked on next , then new intent will be start that gives another activity login acitivity,
//        in the login activity 2 textview(enter username, password), 2 edit text(username, password), 1 button(login)
//        after entering values in edittext and clicking on login buttons that results  the username & password match with =="aa" then create a toast that is "login Correct" with green text color & also new intent should be start with new activity that contains "image view and image button with URi function"
//        and also if
//        if userame and username,password does not match with "aa" then create a toast "wrong credintals" in red color
//        the new activity contains 1 image view and 1 image button url, 1 button(next)
//        that contains 1 image view which have should be loaded by online image with 100*100dp,
//        and below that 100*100dp image button which having also online image
//        if clicking on image button that should be start url function("google.com")
//        if clicked on next acitivity starts that is dialog box
//        which having button if clicked on the button 1 dialog should have to open which cotains proper random message
//
//
//
//
//        hello world, addition of two numbrs, login activity, image,dialog,
